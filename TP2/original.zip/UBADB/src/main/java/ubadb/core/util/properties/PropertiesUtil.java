package ubadb.core.util.properties;

public interface PropertiesUtil
{
	String get(String key);
}
