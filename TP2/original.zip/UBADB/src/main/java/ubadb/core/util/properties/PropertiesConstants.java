package ubadb.core.util.properties;

public abstract class PropertiesConstants
{
	public static final String CATALOG_FILE_NAME = "catalog.file.name";
	public static final String CONFIG_PROPERTIES_FILE_NAME	= "config.properties";
}
