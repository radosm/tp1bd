package ubadb.core.components.catalogManager;

import java.util.List;

import ubadb.core.common.TableId;


/**
 * Serializable class that represents the catalog
 * 
 */
public class Catalog
{
	private List<TableDescriptor> tableDescriptors;

	public TableDescriptor getTableDescriptorByTableId(TableId tableId)
	{
		//TODO Completar
		return null;
	}
}
