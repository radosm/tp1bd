package ubadb.external.bufferManagement.etc;

public enum PageReferenceType
{
	REQUEST,
	RELEASE;
}
